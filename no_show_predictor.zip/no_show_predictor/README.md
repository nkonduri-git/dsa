# No-Show Predictor — Mental Health Clinic

An ML-powered Streamlit web app that predicts which patients are likely to miss their mental health appointments, using a Random Forest classifier trained on scheduling and demographic features.

## What It Does
- Upload an appointment schedule Excel file
- Get instant no-show risk scores (0–100%) per patient
- Risk tiering: High (>60%), Medium (35–60%), Low (<35%)
- Recommended action per patient (call directly, offer telehealth, send reminder)
- Download a color-coded Excel action plan report

## Stack
- Python, scikit-learn (Random Forest), pandas, openpyxl, Streamlit

## Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Data
- `appointments.xlsx` — 300 synthetic appointment records (training data)
- Download template from the app to prepare your own data file

## Features Used
Patient Age, Distance from Clinic, Prior No-Shows, Days Since Scheduled,
Reminders Sent, Hour of Day, Day of Week, Appointment Type, Insurance Type, Provider

## Author
Konduri Naga Venkata Karthik | github.com/nkonduri-git
