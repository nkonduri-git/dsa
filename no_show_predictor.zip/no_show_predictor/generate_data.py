import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)
n = 300

appointment_types = ["Initial Eval","Follow-up","Crisis Support","Group Therapy","Medication Review"]
insurance = ["Medicaid","Medicare","BlueCross","Aetna","Self-Pay","United Health"]
days = ["Monday","Tuesday","Wednesday","Thursday","Friday"]
providers = ["Dr. Smith","Dr. Patel","Dr. Nguyen","Dr. Williams","Dr. Garcia"]

ages = np.random.randint(18, 75, n)
distance_km = np.round(np.random.exponential(12, n), 1)
prior_noshows = np.random.choice([0,0,0,1,1,2,3], n)
days_since_scheduled = np.random.randint(1, 30, n)
appt_type = np.random.choice(appointment_types, n)
insurer = np.random.choice(insurance, n)
day_of_week = np.random.choice(days, n)
provider = np.random.choice(providers, n)
reminders_sent = np.random.choice([0,1,2], n, p=[0.2,0.5,0.3])
hour_of_day = np.random.randint(8, 18, n)

prob = (0.10
    + (distance_km > 20)*0.15
    + (prior_noshows >= 2)*0.25
    + (insurer == "Self-Pay")*0.12
    + (insurer == "Medicaid")*0.08
    + (day_of_week == "Monday")*0.07
    + (appt_type == "Group Therapy")*0.10
    + (reminders_sent == 0)*0.18
    + (days_since_scheduled > 14)*0.10
    - (reminders_sent == 2)*0.12
    - (prior_noshows == 0)*0.05)
prob = np.clip(prob, 0.05, 0.92)
no_show = np.random.binomial(1, prob, n)

base_date = datetime(2025, 5, 1)
appt_dates = [base_date + timedelta(days=random.randint(0,180)) for _ in range(n)]

df = pd.DataFrame({
    "Patient_ID": [f"PT{1000+i}" for i in range(n)],
    "Appointment_Date": [d.strftime("%Y-%m-%d") for d in appt_dates],
    "Day_of_Week": day_of_week,
    "Hour_of_Day": hour_of_day,
    "Provider": provider,
    "Appointment_Type": appt_type,
    "Patient_Age": ages,
    "Insurance_Type": insurer,
    "Distance_km": distance_km,
    "Prior_NoShows": prior_noshows,
    "Days_Since_Scheduled": days_since_scheduled,
    "Reminders_Sent": reminders_sent,
    "No_Show": no_show
})

df.to_excel("/home/claude/projects/no_show_predictor/appointments.xlsx", index=False)
print(f"Generated {n} records, no-show rate: {no_show.mean():.1%}")
