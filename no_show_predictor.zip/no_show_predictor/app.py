import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import io
import warnings
warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="No-Show Predictor | Mental Health Clinic",
    page_icon="🏥",
    layout="wide"
)

# ── CSS ──
st.markdown("""
<style>
  [data-testid="stAppViewContainer"] { background: #f8f9fc; }
  .main-header {
    background: #1B3A6B; color: white; padding: 24px 32px;
    border-radius: 12px; margin-bottom: 24px;
  }
  .main-header h1 { margin:0; font-size:26px; font-weight:700; }
  .main-header p  { margin:4px 0 0; opacity:0.75; font-size:14px; }
  .metric-card {
    background:white; border:1px solid #e2e8f0;
    border-radius:10px; padding:18px 20px; text-align:center;
  }
  .metric-card .val { font-size:30px; font-weight:700; color:#1B3A6B; }
  .metric-card .lbl { font-size:12px; color:#64748b; margin-top:2px; }
  .risk-high   { background:#fee2e2; color:#991b1b; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; }
  .risk-medium { background:#fef3c7; color:#92400e; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; }
  .risk-low    { background:#d1fae5; color:#065f46; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; }
  .section-title { font-size:18px; font-weight:700; color:#1B3A6B; margin:24px 0 12px; border-bottom:2px solid #1B3A6B; padding-bottom:6px; }
  .info-box { background:#eff6ff; border-left:4px solid #1B3A6B; border-radius:0 8px 8px 0; padding:14px 18px; margin:12px 0; font-size:14px; color:#1e3a5f; }
</style>
""", unsafe_allow_html=True)

# ── Header ──
st.markdown("""
<div class="main-header">
  <h1>Mental Health Appointment No-Show Predictor</h1>
  <p>Upload your appointment schedule Excel file — get instant risk scores, ranked alerts, and a downloadable action plan</p>
</div>
""", unsafe_allow_html=True)

# ── Sidebar ──
with st.sidebar:
    st.image("https://via.placeholder.com/200x60/1B3A6B/ffffff?text=ClinicAI", use_column_width=True)
    st.markdown("### How it works")
    st.markdown("""
1. Download the **sample Excel template**
2. Fill in your appointment data
3. Upload the file
4. Get instant risk scores + action plan
    """)
    st.markdown("---")
    st.markdown("### Model Info")
    st.markdown("**Algorithm:** Random Forest")
    st.markdown("**Features:** 10 clinical & scheduling variables")
    st.markdown("**Output:** No-show probability (0–100%)")
    st.markdown("---")
    st.markdown("### Risk Thresholds")
    st.markdown("🔴 **High:** > 60% probability")
    st.markdown("🟡 **Medium:** 35–60%")
    st.markdown("🟢 **Low:** < 35%")

# ── Load & Train Model ──
@st.cache_resource
def train_model():
    try:
        df = pd.read_excel("appointments.xlsx")
    except:
        st.error("appointments.xlsx not found. Please ensure it is in the same directory.")
        st.stop()

    features = ["Patient_Age","Distance_km","Prior_NoShows","Days_Since_Scheduled",
                "Reminders_Sent","Hour_of_Day","Day_of_Week","Appointment_Type",
                "Insurance_Type","Provider"]
    target = "No_Show"

    df_model = df[features + [target]].copy()
    encoders = {}
    for col in ["Day_of_Week","Appointment_Type","Insurance_Type","Provider"]:
        le = LabelEncoder()
        df_model[col] = le.fit_transform(df_model[col].astype(str))
        encoders[col] = le

    X = df_model[features]
    y = df_model[target]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    clf = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42, class_weight="balanced")
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    auc = roc_auc_score(y_test, clf.predict_proba(X_test)[:,1])
    report = classification_report(y_test, y_pred, output_dict=True)

    return clf, encoders, features, auc, report

model, encoders, FEATURES, auc_score, report = train_model()

# ── Sample Download ──
st.markdown('<div class="section-title">Step 1 — Download Template</div>', unsafe_allow_html=True)
st.markdown('<div class="info-box">Download the sample Excel template, fill in your appointment data, then upload it below. Column names must match exactly.</div>', unsafe_allow_html=True)

sample_df = pd.DataFrame({
    "Patient_ID":           ["PT1001","PT1002","PT1003"],
    "Appointment_Date":     ["2025-08-01","2025-08-02","2025-08-03"],
    "Day_of_Week":          ["Monday","Tuesday","Wednesday"],
    "Hour_of_Day":          [9, 14, 11],
    "Provider":             ["Dr. Smith","Dr. Patel","Dr. Nguyen"],
    "Appointment_Type":     ["Follow-up","Initial Eval","Group Therapy"],
    "Patient_Age":          [35, 52, 28],
    "Insurance_Type":       ["BlueCross","Medicaid","Self-Pay"],
    "Distance_km":          [5.2, 22.1, 8.4],
    "Prior_NoShows":        [0, 2, 1],
    "Days_Since_Scheduled": [7, 21, 3],
    "Reminders_Sent":       [2, 0, 1],
})

buf = io.BytesIO()
with pd.ExcelWriter(buf, engine="openpyxl") as writer:
    sample_df.to_excel(writer, index=False, sheet_name="Appointments")
    ws = writer.sheets["Appointments"]
    hdr_fill = PatternFill("solid", fgColor="1B3A6B")
    hdr_font = Font(bold=True, color="FFFFFF", name="Arial")
    for cell in ws[1]:
        cell.fill = hdr_fill
        cell.font = hdr_font
        cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(cell.column)].width = 22
buf.seek(0)
st.download_button("Download Sample Template (.xlsx)", buf, "appointment_template.xlsx",
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                   use_container_width=False)

# ── Upload ──
st.markdown('<div class="section-title">Step 2 — Upload Your Appointment File</div>', unsafe_allow_html=True)
uploaded = st.file_uploader("Upload Excel file (.xlsx)", type=["xlsx"])

# ── Predict ──
def predict_noshows(df_input):
    df = df_input.copy()
    required = ["Day_of_Week","Appointment_Type","Insurance_Type","Provider"]
    for col in required:
        le = encoders[col]
        df[col] = df[col].astype(str).apply(
            lambda x: le.transform([x])[0] if x in le.classes_ else 0
        )
    X = df[FEATURES]
    probs = model.predict_proba(X)[:,1]
    return probs

def risk_label(p):
    if p >= 0.60: return "High"
    if p >= 0.35: return "Medium"
    return "Low"

def make_action(row):
    actions = []
    if row["Prior_NoShows"] >= 2:    actions.append("Call patient directly")
    if row["Distance_km"] > 20:      actions.append("Offer telehealth option")
    if row["Reminders_Sent"] == 0:   actions.append("Send reminder immediately")
    if row["Insurance_Type"] == "Self-Pay": actions.append("Confirm payment plan")
    if row["Day_of_Week"] == "Monday":actions.append("Offer alternate day")
    if not actions:                   actions.append("Send standard reminder")
    return "; ".join(actions)

if uploaded:
    try:
        df_raw = pd.read_excel(uploaded)
        st.success(f"Loaded {len(df_raw)} appointments successfully.")
        st.markdown('<div class="section-title">Step 3 — Predictions & Risk Scores</div>', unsafe_allow_html=True)

        probs = predict_noshows(df_raw)
        df_raw["No_Show_Probability_%"] = (probs * 100).round(1)
        df_raw["Risk_Level"] = df_raw["No_Show_Probability_%"].apply(lambda p: risk_label(p/100))
        df_raw["Recommended_Action"] = df_raw.apply(make_action, axis=1)
        df_sorted = df_raw.sort_values("No_Show_Probability_%", ascending=False).reset_index(drop=True)

        # Metrics
        total = len(df_sorted)
        high   = (df_sorted["Risk_Level"]=="High").sum()
        medium = (df_sorted["Risk_Level"]=="Medium").sum()
        low    = (df_sorted["Risk_Level"]=="Low").sum()
        avg_p  = df_sorted["No_Show_Probability_%"].mean()

        c1,c2,c3,c4,c5 = st.columns(5)
        for col, val, lbl in [
            (c1,total,"Total Appointments"),
            (c2,f"{high} ({high/total:.0%})","High Risk"),
            (c3,f"{medium} ({medium/total:.0%})","Medium Risk"),
            (c4,f"{low} ({low/total:.0%})","Low Risk"),
            (c5,f"{avg_p:.1f}%","Avg No-Show Prob"),
        ]:
            col.markdown(f'<div class="metric-card"><div class="val">{val}</div><div class="lbl">{lbl}</div></div>', unsafe_allow_html=True)

        st.markdown("")

        # Feature importance
        fi = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False)
        st.markdown("**Top predictors driving no-show risk:**")
        fi_cols = st.columns(5)
        for i,(feat,imp) in enumerate(fi.head(5).items()):
            fi_cols[i].metric(feat.replace("_"," "), f"{imp:.1%}")

        # Table with colour coding
        st.markdown("**Ranked appointment list (highest risk first):**")
        display_cols = ["Patient_ID","Appointment_Date","Day_of_Week","Provider",
                        "Appointment_Type","Insurance_Type","No_Show_Probability_%",
                        "Risk_Level","Recommended_Action"]

        def color_risk(val):
            if val == "High":   return "background-color:#fee2e2;color:#991b1b;font-weight:600"
            if val == "Medium": return "background-color:#fef3c7;color:#92400e;font-weight:600"
            return "background-color:#d1fae5;color:#065f46;font-weight:600"

        styled = df_sorted[display_cols].style.applymap(color_risk, subset=["Risk_Level"])
        st.dataframe(styled, use_container_width=True, height=400)

        # Download report
        st.markdown('<div class="section-title">Step 4 — Download Action Plan</div>', unsafe_allow_html=True)
        out = io.BytesIO()
        with pd.ExcelWriter(out, engine="openpyxl") as writer:
            df_sorted.to_excel(writer, index=False, sheet_name="Risk Report")
            ws = writer.sheets["Risk Report"]

            # Header styling
            hf = PatternFill("solid", fgColor="1B3A6B")
            for cell in ws[1]:
                cell.fill = hf
                cell.font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
                cell.alignment = Alignment(horizontal="center")
                ws.column_dimensions[get_column_letter(cell.column)].width = 22

            # Row colour by risk
            fill_map = {"High":"FFCCCC","Medium":"FFF3CC","Low":"CCFFDD"}
            risk_col = df_sorted.columns.get_loc("Risk_Level") + 1
            for row_idx, risk in enumerate(df_sorted["Risk_Level"], start=2):
                fill = PatternFill("solid", fgColor=fill_map.get(risk,"FFFFFF"))
                for cell in ws[row_idx]:
                    cell.fill = fill
                    cell.alignment = Alignment(vertical="center")

            # Summary sheet
            ws2 = writer.book.create_sheet("Summary")
            ws2.append(["Metric","Value"])
            ws2.append(["Total Appointments", total])
            ws2.append(["High Risk",  high])
            ws2.append(["Medium Risk",medium])
            ws2.append(["Low Risk",   low])
            ws2.append(["Avg No-Show Probability", f"{avg_p:.1f}%"])
            ws2.append(["Model AUC", f"{auc_score:.3f}"])
            for cell in ws2["A"]:
                cell.font = Font(bold=True, name="Arial")
            ws2.column_dimensions["A"].width = 28
            ws2.column_dimensions["B"].width = 18

        out.seek(0)
        st.download_button("Download Full Risk Report (.xlsx)", out,
                           "no_show_risk_report.xlsx",
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           use_container_width=True)

    except Exception as e:
        st.error(f"Error processing file: {e}")
else:
    # Default demo using training data
    st.markdown('<div class="section-title">Demo — Using Sample Data</div>', unsafe_allow_html=True)
    st.info("No file uploaded yet. Showing predictions on the built-in sample dataset (appointments.xlsx).")
    try:
        df_demo = pd.read_excel("appointments.xlsx").head(20)
        probs = predict_noshows(df_demo)
        df_demo["No_Show_Probability_%"] = (probs * 100).round(1)
        df_demo["Risk_Level"] = df_demo["No_Show_Probability_%"].apply(lambda p: risk_label(p/100))
        df_demo["Recommended_Action"] = df_demo.apply(make_action, axis=1)
        df_demo = df_demo.sort_values("No_Show_Probability_%", ascending=False)
        display_cols = ["Patient_ID","Day_of_Week","Provider","Appointment_Type","No_Show_Probability_%","Risk_Level","Recommended_Action"]
        st.dataframe(df_demo[display_cols].reset_index(drop=True), use_container_width=True, height=350)
        c1,c2 = st.columns(2)
        c1.metric("Model AUC Score", f"{auc_score:.3f}")
        c2.metric("Sample No-Show Rate", f"{df_demo['No_Show_Probability_%'].mean():.1f}%")
    except: pass

st.markdown("---")
st.caption("No-Show Predictor v1.0 | Random Forest | Built with Streamlit + scikit-learn | Portfolio project — Konduri Naga Venkata Karthik")
