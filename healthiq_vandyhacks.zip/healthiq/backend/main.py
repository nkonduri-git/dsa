"""
HealthIQ Command — FastAPI Backend
Capital One Health Intelligence Platform
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import anthropic
import json
import os
from pathlib import Path
from typing import Optional
from analysis import (
    get_portfolio_summary,
    get_tier1_users,
    get_top_pharmacy_spikes,
    get_health_deserts,
    get_user_by_id,
    get_intervention_breakdown,
)

app = FastAPI(title="HealthIQ Command API", version="1.0.0")

# Allow frontend to call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load dataset once at startup
DATA_PATH = Path(__file__).parent.parent / "data" / "healthiq_synthetic_dataset.json"
with open(DATA_PATH) as f:
    DATASET = json.load(f)

# Anthropic client — reads ANTHROPIC_API_KEY from environment
client = anthropic.Anthropic()


# ── MODELS ──────────────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    mode: str
    messages: list[ChatMessage]

class UserLookupRequest(BaseModel):
    user_id: str


# ── SYSTEM PROMPTS ───────────────────────────────────────────────────────────

def build_system_prompt(mode: str) -> str:
    summary = get_portfolio_summary(DATASET)
    tier1 = get_tier1_users(DATASET)[:5]
    top_pharmacy = get_top_pharmacy_spikes(DATASET)[:5]
    deserts = get_health_deserts(DATASET)[:6]

    dataset_context = f"""
LIVE DATASET — {summary['total_users']} CAPITAL ONE CARDHOLDERS (SYNTHETIC):
- TIER-1 Critical: {summary['tier1_count']} users ({summary['tier1_pct']}%)
- TIER-2 Elevated: {summary['tier2_count']} users
- Uninsured: {summary['uninsured_count']} ({summary['uninsured_pct']}%)
- Avg pharmacy change (3m): +{summary['avg_pharmacy_chg']}%
- Avg default probability: {summary['avg_default_prob']}%
- TIER-1 avg credit utilization: {summary['tier1_avg_util']}%

TOP 5 PHARMACY SPIKE USERS:
{chr(10).join([
    f"- {u['user_id']}: +{u['signals']['pharmacy_3m_change_pct']}% pharmacy, "
    f"util {u['credit']['utilization_pct']}%, "
    f"{u['risk']['risk_tier']}, "
    f"recommended: {u['recommended_intervention']}"
    for u in top_pharmacy
])}

TOP HEALTH SPENDING DESERTS (by ZIP):
{chr(10).join([f"- ZIP {z}: RPR={r}" for z, r in deserts])}

SAMPLE TIER-1 PROFILES:
{chr(10).join([
    f"User {u['user_id']} | Age {u['age']} | {u['state']} {u['zip_code']} | "
    f"{u['insurance']['provider']} {u['insurance']['plan_type']} | "
    f"Pharmacy {u['mcc_spend_3m']['MCC_5912_pharmacy']} | "
    f"Score {u['risk']['crisis_score']}/100 | "
    f"Default prob {u['risk']['default_probability_pct']}% | "
    f"Action: {u['recommended_intervention']}"
    for u in tier1
])}
"""

    base_prompts = {
        "cra": f"""You are HealthIQ Command's CRA Intelligence Agent for Capital One compliance officers.
You identify health spending deserts, model CRA investment strategies, and draft OCC-ready narratives.
Capital One has ~$2.3B in annual CRA obligations. Reference 12 CFR Part 25. Use real zip codes from the dataset.
Always give dollar amounts, OCC rating implications, and measurable community outcomes.
{dataset_context}""",

        "crisis": f"""You are HealthIQ Command's Crisis Detection Agent for Capital One risk analysts.
You identify users at risk of health-driven financial default using MCC signals.
Key MCCs: 5912 pharmacy (spike >30% = danger), 7941 gym (cancellation = stress),
8011 doctors, 8062 hospital, 5411 grocery (decline = food stress), 4121 medical transport.
Intervention within 15-30 days of first signal reduces default by 22%.
{dataset_context}""",

        "risk": f"""You are HealthIQ Command's Default Risk Modeling Agent for quantitative analysts.
Model health-driven credit default. Use: EL = PD x LGD x EAD.
Avg default value: $3,200. Health crisis events precede 66% of US bankruptcies.
Users with pharmacy spike >30% default at 2.8x baseline rate.
{dataset_context}""",

        "equity": f"""You are HealthIQ Command's Health Equity Map Analyst.
You map geographic health spending deserts using the RPR metric (Reactive-to-Preventive Ratio).
RPR > 3.0 = health spending desert. RPR > 5.0 = critical.
Reactive MCCs: 8062, 8011 urgent, 4121. Preventive MCCs: 7941, 8021, 5411.
Use actual zip codes from the dataset. Recommend CRA dollar amounts per zip.
{dataset_context}""",

        "product": f"""You are HealthIQ Command's Product Trigger Engine for Capital One product teams.
Available products: 0% APR Balance Transfer (12-18m), Credit Limit Increase,
Personal Loan (health-specific), Venture Rewards Upgrade, HSA-linked card, Payment Plan.
Give exact trigger conditions, optimal offer timing (day 15-30 of signal),
expected conversion rates, and revenue impact for each scenario.
{dataset_context}""",

        "roi": f"""You are HealthIQ Command's ROI Modeling Agent for Capital One finance teams.
Calculate full business case for health intelligence features.
Use: default reduction value, CRA compliance value, retention lift (40% less churn),
NPS lift (+8-12 points), new product revenue.
Scale: 2.4M users portfolio-wide, $3,200 avg default, $180 annual revenue per cardholder.
Always produce conservative/base/optimistic scenarios with payback period.
{dataset_context}""",
    }

    rules = """
FORMAT RULES:
- Use specific user IDs, zip codes, and numbers from the dataset above
- Structure with clear sections using ### headers
- Every claim needs a number
- End with: "Recommended next action:"
- Speak analyst to analyst — no hand-holding
"""
    return base_prompts.get(mode, base_prompts["cra"]) + rules


# ── ROUTES ───────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "HealthIQ Command API running", "version": "1.0.0"}


@app.get("/api/summary")
def portfolio_summary():
    """Return high-level portfolio stats for the dashboard panels."""
    return get_portfolio_summary(DATASET)


@app.get("/api/tier1")
def tier1_users(limit: int = 20):
    """Return Tier-1 critical users sorted by crisis score."""
    users = get_tier1_users(DATASET)[:limit]
    return {"count": len(users), "users": users}


@app.get("/api/pharmacy-spikes")
def pharmacy_spikes(threshold: float = 20.0, limit: int = 20):
    """Return users with pharmacy spend spike above threshold %."""
    users = get_top_pharmacy_spikes(DATASET, threshold)[:limit]
    return {"threshold_pct": threshold, "count": len(users), "users": users}


@app.get("/api/health-deserts")
def health_deserts(min_rpr: float = 2.0, limit: int = 15):
    """Return zip codes with high reactive-to-preventive spend ratio."""
    deserts = get_health_deserts(DATASET, min_rpr)[:limit]
    return {"min_rpr": min_rpr, "count": len(deserts), "deserts": [
        {"zip": z, "rpr": r} for z, r in deserts
    ]}


@app.get("/api/interventions")
def interventions():
    """Return breakdown of recommended interventions across all users."""
    return get_intervention_breakdown(DATASET)


@app.get("/api/user/{user_id}")
def user_detail(user_id: str):
    """Look up a specific user by ID."""
    user = get_user_by_id(DATASET, user_id.upper())
    if not user:
        raise HTTPException(status_code=404, detail=f"User {user_id} not found")
    return user


@app.post("/api/chat")
def chat(req: ChatRequest):
    """
    Main AI chat endpoint. Calls Claude with mode-specific system prompt
    and full conversation history.
    """
    system_prompt = build_system_prompt(req.mode)
    messages = [{"role": m.role, "content": m.content} for m in req.messages]

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        system=system_prompt,
        messages=messages,
    )

    return {
        "content": response.content[0].text,
        "input_tokens": response.usage.input_tokens,
        "output_tokens": response.usage.output_tokens,
    }


@app.get("/api/dataset/stats")
def dataset_stats():
    """Return full summary stats for the dataset."""
    users = DATASET["users"]
    # Risk distribution
    risk_dist = {}
    plan_dist = {}
    state_dist = {}
    for u in users:
        t = u["risk"]["risk_tier"]
        risk_dist[t] = risk_dist.get(t, 0) + 1
        p = u["insurance"]["plan_type"]
        plan_dist[p] = plan_dist.get(p, 0) + 1
        s = u["state"]
        state_dist[s] = state_dist.get(s, 0) + 1

    return {
        "total": len(users),
        "risk_distribution": risk_dist,
        "plan_distribution": plan_dist,
        "state_distribution": dict(sorted(state_dist.items(), key=lambda x: -x[1])),
        "metadata": DATASET["metadata"],
        "summary": DATASET["summary"],
    }
