"""
HealthIQ — Data Analysis Module
All analytics functions that power the API endpoints and AI context.
"""

from collections import defaultdict
from typing import Any


def get_portfolio_summary(dataset: dict) -> dict:
    users = dataset["users"]
    total = len(users)

    tier_counts = defaultdict(int)
    uninsured = 0
    pharmacy_changes = []
    default_probs = []
    tier1_utils = []

    for u in users:
        tier = u["risk"]["risk_tier"]
        tier_counts[tier] += 1
        if u["insurance"]["provider"] == "Uninsured":
            uninsured += 1
        pharmacy_changes.append(u["signals"]["pharmacy_3m_change_pct"])
        default_probs.append(u["risk"]["default_probability_pct"])
        if tier == "TIER-1":
            tier1_utils.append(u["credit"]["utilization_pct"])

    return {
        "total_users": total,
        "tier1_count": tier_counts["TIER-1"],
        "tier2_count": tier_counts["TIER-2"],
        "tier3_count": tier_counts["TIER-3"],
        "tier4_count": tier_counts["TIER-4"],
        "tier1_pct": round(tier_counts["TIER-1"] / total * 100, 1),
        "tier2_pct": round(tier_counts["TIER-2"] / total * 100, 1),
        "uninsured_count": uninsured,
        "uninsured_pct": round(uninsured / total * 100, 1),
        "avg_pharmacy_chg": round(sum(pharmacy_changes) / len(pharmacy_changes), 1),
        "avg_default_prob": round(sum(default_probs) / len(default_probs), 1),
        "tier1_avg_util": round(
            sum(tier1_utils) / len(tier1_utils) if tier1_utils else 0, 1
        ),
    }


def get_tier1_users(dataset: dict) -> list:
    """Return Tier-1 users sorted by crisis score descending."""
    users = [u for u in dataset["users"] if u["risk"]["risk_tier"] == "TIER-1"]
    return sorted(users, key=lambda u: u["risk"]["crisis_score"], reverse=True)


def get_top_pharmacy_spikes(dataset: dict, threshold: float = 0.0) -> list:
    """Return users with pharmacy spike above threshold, sorted by spike size."""
    users = [
        u for u in dataset["users"]
        if u["signals"]["pharmacy_3m_change_pct"] >= threshold
    ]
    return sorted(
        users,
        key=lambda u: u["signals"]["pharmacy_3m_change_pct"],
        reverse=True
    )


def get_health_deserts(dataset: dict, min_rpr: float = 2.0) -> list[tuple]:
    """
    Compute average reactive-to-preventive ratio per ZIP code.
    Returns list of (zip, avg_rpr) tuples sorted by RPR descending.
    """
    zip_rprs = defaultdict(list)
    for u in dataset["users"]:
        zip_rprs[u["zip_code"]].append(u["signals"]["reactive_to_preventive_ratio"])

    zip_avg = {
        z: round(sum(v) / len(v), 2)
        for z, v in zip_rprs.items()
        if len(v) >= 2
    }

    deserts = [(z, r) for z, r in zip_avg.items() if r >= min_rpr]
    return sorted(deserts, key=lambda x: -x[1])


def get_user_by_id(dataset: dict, user_id: str) -> dict | None:
    """Look up a single user by their ID."""
    for u in dataset["users"]:
        if u["user_id"] == user_id:
            return u
    return None


def get_intervention_breakdown(dataset: dict) -> dict:
    """Return count of each recommended intervention across all users."""
    counts = defaultdict(int)
    for u in dataset["users"]:
        counts[u["recommended_intervention"]] += 1
    return dict(sorted(counts.items(), key=lambda x: -x[1]))


def get_state_risk_profile(dataset: dict) -> dict:
    """Return per-state risk summary."""
    state_data = defaultdict(lambda: {"total": 0, "tier1": 0, "uninsured": 0, "avg_crisis": []})
    for u in dataset["users"]:
        s = u["state"]
        state_data[s]["total"] += 1
        if u["risk"]["risk_tier"] == "TIER-1":
            state_data[s]["tier1"] += 1
        if u["insurance"]["provider"] == "Uninsured":
            state_data[s]["uninsured"] += 1
        state_data[s]["avg_crisis"].append(u["risk"]["crisis_score"])

    result = {}
    for state, d in state_data.items():
        result[state] = {
            "total": d["total"],
            "tier1": d["tier1"],
            "tier1_pct": round(d["tier1"] / d["total"] * 100, 1),
            "uninsured": d["uninsured"],
            "avg_crisis_score": round(sum(d["avg_crisis"]) / len(d["avg_crisis"]), 1),
        }
    return dict(sorted(result.items(), key=lambda x: -x[1]["tier1_pct"]))


def get_mcc_trends(dataset: dict) -> dict:
    """Aggregate average MCC spend trends across all users."""
    mcc_keys = [
        "MCC_5912_pharmacy",
        "MCC_7941_gym_fitness",
        "MCC_8011_doctors",
        "MCC_8062_hospital",
        "MCC_5411_grocery",
        "MCC_4121_medical_transport",
    ]

    totals = {k: [0, 0, 0] for k in mcc_keys}
    n = len(dataset["users"])

    for u in dataset["users"]:
        for k in mcc_keys:
            for i, v in enumerate(u["mcc_spend_3m"][k]):
                totals[k][i] += v

    averages = {
        k: [round(v / n, 2) for v in monthly]
        for k, monthly in totals.items()
    }
    return averages


def flag_high_risk_combinations(dataset: dict) -> list:
    """
    Find users matching the most dangerous combined signal pattern:
    pharmacy spike > 30% AND utilization > 65% AND hospital charge present.
    """
    flagged = []
    for u in dataset["users"]:
        pharmacy_spike = u["signals"]["pharmacy_3m_change_pct"] > 30
        high_util = u["credit"]["utilization_pct"] > 65
        hospital_charge = u["signals"]["hospital_charge_present"]

        if pharmacy_spike and high_util and hospital_charge:
            flagged.append({
                "user_id": u["user_id"],
                "crisis_score": u["risk"]["crisis_score"],
                "pharmacy_change_pct": u["signals"]["pharmacy_3m_change_pct"],
                "utilization_pct": u["credit"]["utilization_pct"],
                "default_prob_pct": u["risk"]["default_probability_pct"],
                "state": u["state"],
                "zip_code": u["zip_code"],
                "recommended_intervention": u["recommended_intervention"],
            })

    return sorted(flagged, key=lambda x: -x["crisis_score"])
