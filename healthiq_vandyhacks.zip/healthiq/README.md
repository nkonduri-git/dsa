# HealthIQ Command — Setup Guide
## Capital One Health Intelligence Platform — VandyHacks

---

## What This Is

Two things:
1. A FastAPI backend that serves your synthetic dataset and connects to Claude
2. A standalone HTML frontend (HealthIQ Command) that talks to the backend

---

## Folder Structure

```
healthiq/
  backend/
    main.py          <- FastAPI server, all routes, Claude integration
    analysis.py      <- All data analysis functions
    requirements.txt <- Python dependencies
  data/
    healthiq_synthetic_dataset.json   <- 500 synthetic users
  notebooks/
    analysis.ipynb   <- Jupyter analysis notebook
  frontend/
    healthiq_command_final.html       <- The agent UI (copy here from outputs)
  .env.example       <- Copy to .env and add your API key
```

---

## Step-by-Step Setup

### Step 1 — Get your Anthropic API key

1. Go to https://console.anthropic.com/
2. Sign in or create account
3. Click "API Keys" in left sidebar
4. Click "Create Key"
5. Copy the key — it starts with `sk-ant-`

---

### Step 2 — Set up Python environment

Open your terminal and run these commands one by one:

```bash
# Check you have Python 3.10+
python3 --version

# Go into the project folder
cd healthiq

# Create a virtual environment (keeps dependencies isolated)
python3 -m venv venv

# Activate it
# On Mac/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Your terminal prompt should now show (venv)
```

---

### Step 3 — Install dependencies

```bash
# Make sure you're in the healthiq/ folder with venv active
pip install -r backend/requirements.txt

# This installs: fastapi, uvicorn, anthropic, pydantic
# Takes about 30 seconds
```

---

### Step 4 — Set your API key

```bash
# Copy the example env file
cp .env.example .env

# Open .env in any text editor and replace the placeholder:
# ANTHROPIC_API_KEY=sk-ant-your-key-here
# with your actual key from Step 1

# On Mac you can do:
nano .env
# Then paste your key, Ctrl+X to save

# OR just export it directly in your terminal:
export ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxx
```

---

### Step 5 — Run the backend server

```bash
# From the healthiq/ folder:
uvicorn backend.main:app --reload --port 8000

# You should see:
# INFO:     Uvicorn running on http://127.0.0.1:8000
# INFO:     Application startup complete.

# Keep this terminal open — it's your running server
```

---

### Step 6 — Test the API is working

Open a new terminal tab and run:

```bash
# Test the server is up
curl http://localhost:8000/

# Should return: {"status":"HealthIQ Command API running","version":"1.0.0"}

# Test the dataset loaded
curl http://localhost:8000/api/summary

# Should return JSON with tier counts, uninsured %, etc.

# Test getting tier-1 users
curl http://localhost:8000/api/tier1?limit=3

# Test health deserts
curl http://localhost:8000/api/health-deserts

# Test a specific user
curl http://localhost:8000/api/user/C1-000001
```

---

### Step 7 — Open the frontend

Option A — simplest for demo:
```bash
# Just open the HTML file directly in your browser
open frontend/healthiq_command_final.html
# On Windows: start frontend/healthiq_command_final.html
```

Option B — serve it properly (better for demo):
```bash
# In a new terminal tab, from healthiq/ folder:
python3 -m http.server 3000 --directory frontend

# Then open: http://localhost:3000/healthiq_command_final.html
```

---

### Step 8 — Connect frontend to backend (optional upgrade)

The current frontend calls Claude directly from the browser.
To route through your backend instead, edit healthiq_command_final.html:

Find this line:
```javascript
const r = await fetch('https://api.anthropic.com/v1/messages', {
```

Replace with:
```javascript
const r = await fetch('http://localhost:8000/api/chat', {
```

And change the body format to match the backend:
```javascript
body: JSON.stringify({
  mode: mode,
  messages: msgs
})
```

---

### Step 9 — Run the Jupyter analysis notebook

```bash
# Install Jupyter if you don't have it
pip install jupyter matplotlib pandas numpy

# Launch notebook
jupyter notebook notebooks/analysis.ipynb

# This opens in your browser
# Run each cell with Shift+Enter
# Generates 3 plots saved to data/
```

---

## API Reference

All endpoints return JSON.

| Method | Endpoint | What it does |
|--------|----------|--------------|
| GET | /api/summary | Portfolio-level KPIs |
| GET | /api/tier1?limit=20 | Critical users by crisis score |
| GET | /api/pharmacy-spikes?threshold=30 | Users with pharmacy spike above % |
| GET | /api/health-deserts?min_rpr=3.0 | ZIP codes above RPR threshold |
| GET | /api/interventions | Breakdown of recommended actions |
| GET | /api/user/{user_id} | Single user full profile |
| GET | /api/dataset/stats | Full dataset statistics |
| POST | /api/chat | Claude AI chat (mode + messages) |

---

## Chat API Example

```bash
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "crisis",
    "messages": [
      {
        "role": "user",
        "content": "Show me the top 5 at-risk users and what to do for each"
      }
    ]
  }'
```

---

## Nessie API (Capital One Hackathon Sandbox)

To add real Capital One transaction data to your demo:

1. Go to http://api.nessieisreal.com
2. Create account — get API key instantly
3. Call their API to get fake accounts and transactions:

```python
import requests

NESSIE_KEY = "your-nessie-key"
BASE = "http://api.nessieisreal.com"

# Get all accounts
accounts = requests.get(f"{BASE}/accounts?key={NESSIE_KEY}").json()

# Get purchases for an account
purchases = requests.get(
    f"{BASE}/accounts/{account_id}/purchases?key={NESSIE_KEY}"
).json()

# Filter by merchant category (MCC equivalent)
pharmacy_purchases = [p for p in purchases if 'pharmacy' in p.get('merchant_id','').lower()]
```

Add a `/api/nessie/user/{account_id}` route to main.py that fetches
real Nessie transactions and merges with your synthetic risk profile.
That combination — synthetic health risk + real transaction data — is
the full demo story.

---

## Common Errors

**"ANTHROPIC_API_KEY not found"**
Run: `export ANTHROPIC_API_KEY=sk-ant-your-key`

**"ModuleNotFoundError: No module named 'fastapi'"**
Make sure venv is active: `source venv/bin/activate` then `pip install -r backend/requirements.txt`

**"FileNotFoundError: healthiq_synthetic_dataset.json"**
Make sure the JSON file is in the `data/` folder

**Port 8000 already in use**
Run: `uvicorn backend.main:app --reload --port 8001`
Then update the frontend fetch URL to match

**CORS error in browser**
Already handled in main.py with CORSMiddleware. If still failing,
make sure the backend is actually running on port 8000.
