# Loan Default Batch Scorer — Credit Risk

An ML-powered Streamlit web app that scores loan applicants' default probability using Gradient Boosting, with tiered credit decisions and a downloadable risk report.

## What It Does
- Upload a loan applicant Excel file (batch scoring)
- Get default probability scores (0–100%) per applicant
- Three-tier decision: Approve (<25%), Manual Review (25–55%), Decline (>55%)
- What-if simulator: adjust credit score, DTI, missed payments and see score change
- Download color-coded Excel decision report with summary sheet

## Stack
- Python, scikit-learn (Gradient Boosting), pandas, openpyxl, Streamlit

## Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Data
- `loan_applicants.xlsx` — 300 synthetic loan applicant records (training data)
- Download template from the app to prepare your own applicant file

## Features Used
Age, Annual Income, Loan Amount, Loan Term, Credit Score, Debt-to-Income Ratio,
Months Employed, Existing Loans, Missed Payments, Employment Type, Loan Purpose

## Author
Konduri Naga Venkata Karthik | github.com/nkonduri-git
