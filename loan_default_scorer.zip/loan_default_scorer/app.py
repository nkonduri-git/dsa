import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, classification_report
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
import io
import warnings
warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="Loan Default Scorer | Credit Risk",
    page_icon="💳",
    layout="wide"
)

st.markdown("""
<style>
  [data-testid="stAppViewContainer"] { background: #f5f7ff; }
  .main-header {
    background: linear-gradient(135deg, #14532d 0%, #166534 100%);
    color:white; padding:24px 32px; border-radius:12px; margin-bottom:24px;
  }
  .main-header h1 { margin:0; font-size:26px; font-weight:700; }
  .main-header p  { margin:4px 0 0; opacity:0.75; font-size:14px; }
  .metric-card {
    background:white; border:1px solid #e2e8f0;
    border-radius:10px; padding:18px 20px; text-align:center;
  }
  .metric-card .val { font-size:28px; font-weight:700; color:#14532d; }
  .metric-card .lbl { font-size:12px; color:#64748b; margin-top:2px; }
  .decision-approve { background:#dcfce7; color:#14532d; padding:5px 12px; border-radius:20px; font-size:12px; font-weight:700; }
  .decision-review  { background:#fef3c7; color:#92400e; padding:5px 12px; border-radius:20px; font-size:12px; font-weight:700; }
  .decision-decline { background:#fee2e2; color:#991b1b; padding:5px 12px; border-radius:20px; font-size:12px; font-weight:700; }
  .section-title { font-size:18px; font-weight:700; color:#14532d; margin:24px 0 12px; border-bottom:2px solid #14532d; padding-bottom:6px; }
  .info-box { background:#f0fdf4; border-left:4px solid #16a34a; border-radius:0 8px 8px 0; padding:14px 18px; margin:12px 0; font-size:14px; color:#14532d; }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="main-header">
  <h1>Loan Default Batch Scorer</h1>
  <p>Upload your applicant Excel sheet — get instant default probability scores, tiered decisions, and a downloadable credit risk report</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("### How it works")
    st.markdown("""
1. Download the **sample template**
2. Fill in applicant data
3. Upload — get scored instantly
4. Download the decision report
    """)
    st.markdown("---")
    st.markdown("### Decision Tiers")
    st.markdown("🟢 **Approve:** < 25% default risk")
    st.markdown("🟡 **Manual Review:** 25–55%")
    st.markdown("🔴 **Decline:** > 55% default risk")
    st.markdown("---")
    st.markdown("### Model Info")
    st.markdown("**Algorithm:** Gradient Boosting")
    st.markdown("**Features:** 11 applicant variables")
    st.markdown("**Trained on:** 300 synthetic loan records")

# ── Train Model ──
@st.cache_resource
def train_model():
    try:
        df = pd.read_excel("loan_applicants.xlsx")
    except:
        st.error("loan_applicants.xlsx not found.")
        st.stop()

    features = ["Age","Annual_Income_USD","Loan_Amount_USD","Loan_Term_Months",
                "Credit_Score","Debt_to_Income_Ratio","Months_Employed",
                "Existing_Loans","Missed_Payments_12mo","Employment_Type","Loan_Purpose"]
    target = "Default"

    df2 = df[features + [target]].copy()
    encoders = {}
    for col in ["Employment_Type","Loan_Purpose"]:
        le = LabelEncoder()
        df2[col] = le.fit_transform(df2[col].astype(str))
        encoders[col] = le

    X = df2[features]; y = df2[target]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    clf = GradientBoostingClassifier(n_estimators=200, learning_rate=0.08, max_depth=4, random_state=42)
    clf.fit(Xtr, ytr)
    auc = roc_auc_score(yte, clf.predict_proba(Xte)[:,1])
    report = classification_report(yte, clf.predict(Xte), output_dict=True)
    return clf, encoders, features, auc, report

model, encoders, FEATURES, auc_score, report = train_model()

def decision(p):
    if p < 0.25: return "Approve"
    if p < 0.55: return "Manual Review"
    return "Decline"

def top_risk_factors(row):
    flags = []
    if row.get("Credit_Score",750) < 620:        flags.append("Low credit score")
    if row.get("Debt_to_Income_Ratio",0) > 0.40: flags.append("High DTI ratio")
    if row.get("Missed_Payments_12mo",0) >= 2:   flags.append("Missed payments")
    if row.get("Employment_Type","") == "Unemployed": flags.append("Unemployed")
    if row.get("Existing_Loans",0) >= 3:          flags.append("Too many existing loans")
    if row.get("Loan_Amount_USD",0) / max(row.get("Annual_Income_USD",1),1) > 0.6: flags.append("High loan-to-income")
    return "; ".join(flags) if flags else "No major risk flags"

def predict_batch(df_input):
    df = df_input.copy()
    for col in ["Employment_Type","Loan_Purpose"]:
        le = encoders[col]
        df[col] = df[col].astype(str).apply(
            lambda x: le.transform([x])[0] if x in le.classes_ else 0
        )
    return model.predict_proba(df[FEATURES])[:,1]

# ── Sample Template ──
st.markdown('<div class="section-title">Step 1 — Download Template</div>', unsafe_allow_html=True)
st.markdown('<div class="info-box">Download the template, fill in your applicants, then upload. Column headers must match exactly.</div>', unsafe_allow_html=True)

sample = pd.DataFrame({
    "Applicant_ID":          ["LN2001","LN2002","LN2003"],
    "Age":                   [34, 52, 27],
    "Annual_Income_USD":     [68000, 45000, 31000],
    "Loan_Amount_USD":       [15000, 28000, 8000],
    "Loan_Purpose":          ["Debt Consolidation","Home Improvement","Medical"],
    "Loan_Term_Months":      [36, 60, 24],
    "Credit_Score":          [710, 590, 640],
    "Debt_to_Income_Ratio":  [0.22, 0.48, 0.31],
    "Employment_Type":       ["Full-time","Part-time","Self-employed"],
    "Months_Employed":       [84, 24, 36],
    "Existing_Loans":        [1, 3, 0],
    "Missed_Payments_12mo":  [0, 2, 1],
    "Region":                ["Midwest","South","Northeast"],
})

buf = io.BytesIO()
with pd.ExcelWriter(buf, engine="openpyxl") as writer:
    sample.to_excel(writer, index=False, sheet_name="Applicants")
    ws = writer.sheets["Applicants"]
    hf = PatternFill("solid", fgColor="14532d")
    for cell in ws[1]:
        cell.fill = hf
        cell.font = Font(bold=True, color="FFFFFF", name="Arial")
        cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(cell.column)].width = 24
buf.seek(0)
st.download_button("Download Applicant Template (.xlsx)", buf, "loan_applicant_template.xlsx",
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# ── Upload ──
st.markdown('<div class="section-title">Step 2 — Upload Applicant File</div>', unsafe_allow_html=True)
uploaded = st.file_uploader("Upload Excel file (.xlsx)", type=["xlsx"])

if uploaded:
    try:
        df_raw = pd.read_excel(uploaded)
        st.success(f"Loaded {len(df_raw)} applicants.")
        st.markdown('<div class="section-title">Step 3 — Scores & Decisions</div>', unsafe_allow_html=True)

        probs = predict_batch(df_raw)
        df_raw["Default_Probability_%"] = (probs*100).round(1)
        df_raw["Decision"] = df_raw["Default_Probability_%"].apply(lambda p: decision(p/100))
        df_raw["Risk_Factors"] = df_raw.apply(top_risk_factors, axis=1)
        df_sorted = df_raw.sort_values("Default_Probability_%", ascending=False).reset_index(drop=True)

        total    = len(df_sorted)
        approve  = (df_sorted["Decision"]=="Approve").sum()
        review   = (df_sorted["Decision"]=="Manual Review").sum()
        decline  = (df_sorted["Decision"]=="Decline").sum()
        avg_prob = df_sorted["Default_Probability_%"].mean()

        c1,c2,c3,c4,c5 = st.columns(5)
        for col, val, lbl in [
            (c1, total, "Total Applicants"),
            (c2, f"{approve} ({approve/total:.0%})", "Approved"),
            (c3, f"{review} ({review/total:.0%})", "Manual Review"),
            (c4, f"{decline} ({decline/total:.0%})", "Declined"),
            (c5, f"{avg_prob:.1f}%", "Avg Default Risk"),
        ]:
            col.markdown(f'<div class="metric-card"><div class="val">{val}</div><div class="lbl">{lbl}</div></div>', unsafe_allow_html=True)

        st.markdown("")
        fi = pd.Series(model.feature_importances_, index=FEATURES).sort_values(ascending=False)
        st.markdown("**Top default risk drivers:**")
        fi_cols = st.columns(5)
        for i,(feat,imp) in enumerate(fi.head(5).items()):
            fi_cols[i].metric(feat.replace("_"," "), f"{imp:.1%}")

        # What-if simulator
        with st.expander("What-If Simulator — adjust a single applicant"):
            st.markdown("Select a row from the results above and tweak variables to see how the score changes.")
            applicant_ids = df_sorted["Applicant_ID"].tolist() if "Applicant_ID" in df_sorted.columns else [str(i) for i in range(total)]
            sel = st.selectbox("Select applicant", applicant_ids)
            idx = applicant_ids.index(sel)
            row = df_sorted.iloc[idx].copy()
            col_a, col_b, col_c = st.columns(3)
            new_cs = col_a.slider("Credit Score", 550, 820, int(row.get("Credit_Score",680)))
            new_dti = col_b.slider("Debt-to-Income Ratio", 0.05, 0.55, float(row.get("Debt_to_Income_Ratio",0.30)), 0.01)
            new_mp  = col_c.slider("Missed Payments (12mo)", 0, 5, int(row.get("Missed_Payments_12mo",0)))
            row_mod = row.copy()
            row_mod["Credit_Score"] = new_cs
            row_mod["Debt_to_Income_Ratio"] = new_dti
            row_mod["Missed_Payments_12mo"] = new_mp
            df_mod = pd.DataFrame([row_mod])
            p_new = predict_batch(df_mod)[0]
            p_old = row["Default_Probability_%"]/100
            col_x, col_y = st.columns(2)
            col_x.metric("Original Default Risk", f"{p_old:.1%}")
            col_y.metric("Adjusted Default Risk", f"{p_new:.1%}", delta=f"{(p_new-p_old)*100:+.1f}pp")
            st.markdown(f"**Decision would be:** `{decision(p_new)}`")

        # Table
        st.markdown("**Ranked applicant results:**")
        display_cols = ["Applicant_ID","Age","Annual_Income_USD","Loan_Amount_USD",
                        "Credit_Score","Debt_to_Income_Ratio","Default_Probability_%","Decision","Risk_Factors"]
        display_cols = [c for c in display_cols if c in df_sorted.columns]

        def color_decision(val):
            if val=="Approve":        return "background-color:#dcfce7;color:#14532d;font-weight:700"
            if val=="Manual Review":  return "background-color:#fef3c7;color:#92400e;font-weight:700"
            return "background-color:#fee2e2;color:#991b1b;font-weight:700"

        styled = df_sorted[display_cols].style.applymap(color_decision, subset=["Decision"])
        st.dataframe(styled, use_container_width=True, height=400)

        # Download
        st.markdown('<div class="section-title">Step 4 — Download Decision Report</div>', unsafe_allow_html=True)
        out = io.BytesIO()
        with pd.ExcelWriter(out, engine="openpyxl") as writer:
            df_sorted.to_excel(writer, index=False, sheet_name="Loan Decisions")
            ws = writer.sheets["Loan Decisions"]
            hf2 = PatternFill("solid", fgColor="14532d")
            for cell in ws[1]:
                cell.fill = hf2
                cell.font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
                cell.alignment = Alignment(horizontal="center")
                ws.column_dimensions[get_column_letter(cell.column)].width = 22
            fill_map = {"Approve":"CCFFDD","Manual Review":"FFF3CC","Decline":"FFCCCC"}
            dec_col_idx = list(df_sorted.columns).index("Decision") + 1
            for row_idx, dec in enumerate(df_sorted["Decision"], start=2):
                fill = PatternFill("solid", fgColor=fill_map.get(dec,"FFFFFF"))
                for cell in ws[row_idx]:
                    cell.fill = fill
                    cell.alignment = Alignment(vertical="center")

            ws2 = writer.book.create_sheet("Summary")
            ws2.append(["Decision","Count","Percentage"])
            for dec, cnt in [("Approve",approve),("Manual Review",review),("Decline",decline)]:
                ws2.append([dec, cnt, f"{cnt/total:.1%}"])
            ws2.append(["Total", total, "100%"])
            ws2.append([])
            ws2.append(["Model AUC", f"{auc_score:.3f}"])
            ws2.append(["Avg Default Probability", f"{avg_prob:.1f}%"])
            for cell in ws2["A"]: cell.font = Font(bold=True, name="Arial")
            ws2.column_dimensions["A"].width = 22
            ws2.column_dimensions["B"].width = 12
            ws2.column_dimensions["C"].width = 16

        out.seek(0)
        st.download_button("Download Loan Decision Report (.xlsx)", out,
                           "loan_decision_report.xlsx",
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           use_container_width=True)

    except Exception as e:
        st.error(f"Error: {e}")

else:
    st.markdown('<div class="section-title">Demo — Sample Dataset Preview</div>', unsafe_allow_html=True)
    st.info("No file uploaded yet. Showing demo predictions on the built-in loan_applicants.xlsx.")
    try:
        df_demo = pd.read_excel("loan_applicants.xlsx").head(20)
        probs = predict_batch(df_demo)
        df_demo["Default_Probability_%"] = (probs*100).round(1)
        df_demo["Decision"] = df_demo["Default_Probability_%"].apply(lambda p: decision(p/100))
        df_demo["Risk_Factors"] = df_demo.apply(top_risk_factors, axis=1)
        df_demo = df_demo.sort_values("Default_Probability_%", ascending=False)
        show = ["Applicant_ID","Age","Annual_Income_USD","Credit_Score","Debt_to_Income_Ratio","Default_Probability_%","Decision"]
        st.dataframe(df_demo[show].reset_index(drop=True), use_container_width=True, height=350)
        c1,c2 = st.columns(2)
        c1.metric("Model AUC", f"{auc_score:.3f}")
        c2.metric("Avg Default Risk", f"{df_demo['Default_Probability_%'].mean():.1f}%")
    except: pass

st.markdown("---")
st.caption("Loan Default Scorer v1.0 | Gradient Boosting | Built with Streamlit + scikit-learn | Portfolio project — Konduri Naga Venkata Karthik")
