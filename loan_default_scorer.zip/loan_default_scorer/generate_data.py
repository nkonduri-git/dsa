import pandas as pd
import numpy as np

np.random.seed(99)
n = 300

purposes = ["Home Improvement","Debt Consolidation","Medical","Auto","Education","Small Business","Personal"]
emp_types = ["Full-time","Part-time","Self-employed","Contract","Unemployed"]
regions = ["Northeast","Midwest","South","West","Southwest"]

ages = np.random.randint(22, 65, n)
income = np.round(np.random.lognormal(10.8, 0.5, n), -2)
loan_amount = np.round(np.random.uniform(2000, 50000, n), -2)
credit_score = np.random.randint(550, 820, n)
dti = np.round(np.random.uniform(0.05, 0.55, n), 3)
emp_type = np.random.choice(emp_types, n, p=[0.55,0.15,0.12,0.12,0.06])
loan_purpose = np.random.choice(purposes, n)
loan_term_months = np.random.choice([12,24,36,48,60], n)
existing_loans = np.random.randint(0, 5, n)
missed_payments = np.random.choice([0,0,0,1,2,3], n)
region = np.random.choice(regions, n)
months_employed = np.random.randint(0, 240, n)

prob = (0.08
    + (credit_score < 620)*0.30
    + (credit_score < 580)*0.15
    + (dti > 0.40)*0.20
    + (dti > 0.50)*0.10
    + (emp_type == "Unemployed")*0.35
    + (emp_type == "Self-employed")*0.08
    + (missed_payments >= 2)*0.25
    + (loan_amount / (income+1) > 0.6)*0.15
    + (existing_loans >= 3)*0.10
    - (credit_score > 750)*0.15
    - (months_employed > 60)*0.08
    - (missed_payments == 0)*0.05)
prob = np.clip(prob, 0.02, 0.95)
default = np.random.binomial(1, prob, n)

df = pd.DataFrame({
    "Applicant_ID": [f"LN{2000+i}" for i in range(n)],
    "Age": ages,
    "Annual_Income_USD": income.astype(int),
    "Loan_Amount_USD": loan_amount.astype(int),
    "Loan_Purpose": loan_purpose,
    "Loan_Term_Months": loan_term_months,
    "Credit_Score": credit_score,
    "Debt_to_Income_Ratio": dti,
    "Employment_Type": emp_type,
    "Months_Employed": months_employed,
    "Existing_Loans": existing_loans,
    "Missed_Payments_12mo": missed_payments,
    "Region": region,
    "Default": default
})

df.to_excel("/home/claude/projects/loan_default_scorer/loan_applicants.xlsx", index=False)
print(f"Generated {n} records, default rate: {default.mean():.1%}")
